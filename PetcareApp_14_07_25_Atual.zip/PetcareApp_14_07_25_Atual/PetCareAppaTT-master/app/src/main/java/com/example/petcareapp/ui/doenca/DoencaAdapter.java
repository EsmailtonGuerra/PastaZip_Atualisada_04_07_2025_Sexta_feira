package com.example.petcareapp.ui.doenca;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.Doenca;
import com.example.petcareapp.R;

import java.util.List;

public class DoencaAdapter extends RecyclerView.Adapter<DoencaAdapter.DoencaViewHolder> {

    private List<Doenca> lista;
    private OnItemClickListener listener;
    private int selectedPosition = RecyclerView.NO_POSITION;

    public DoencaAdapter(List<Doenca> lista) {
        this.lista = lista;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setSelectedPosition(int position) {
        int oldPosition = selectedPosition;
        selectedPosition = position;
        notifyItemChanged(oldPosition);
        notifyItemChanged(position);
    }

    public interface OnItemClickListener {
        void onItemClick(Doenca doenca);
    }

    @NonNull
    @Override
    public DoencaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tabela_doenca, parent, false);
        return new DoencaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull DoencaViewHolder holder, int position) {
        Doenca d = lista.get(position);

        holder.tvId.setText(String.valueOf(d.getId()));
        holder.tvEspecie.setText(d.getEspecie());
        holder.tvNome.setText(d.getNomeAnimal());
        holder.tvRaca.setText(d.getRacaAnimal());
        holder.tvDoenca.setText(d.getNomeDoenca());
        holder.tvDetalhes.setText(d.getDetalhesDoenca());

        // Define cor de fundo dependendo da seleção
        if (selectedPosition == position) {
            holder.container.setBackgroundColor(Color.parseColor("#FFEBEE")); // Item selecionado
        } else {
            holder.container.setBackgroundColor(Color.parseColor("#F5F5F5")); // Fundo padrão
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(d);
                setSelectedPosition(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    static class DoencaViewHolder extends RecyclerView.ViewHolder {
        TextView tvId, tvEspecie, tvNome, tvRaca, tvDoenca, tvDetalhes;
        LinearLayout container;

        DoencaViewHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.item_container);
            tvId = itemView.findViewById(R.id.item_id);
            tvEspecie = itemView.findViewById(R.id.item_especie);
            tvNome = itemView.findViewById(R.id.item_nome);
            tvRaca = itemView.findViewById(R.id.item_raca);
            tvDoenca = itemView.findViewById(R.id.item_doenca);
            tvDetalhes = itemView.findViewById(R.id.item_detalhes);
        }
    }
}
